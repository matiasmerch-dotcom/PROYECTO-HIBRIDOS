% Copyright 2025 The MathWorks, Inc.

%% Radiator

vehicleThermal.radiator_L = 0.6; % [m] Overall radiator length
vehicleThermal.radiator_W = 0.015; % [m] Overall radiator width
vehicleThermal.radiator_H = 0.2; % [m] Overal radiator height
vehicleThermal.radiator_N_tubes = 25; % Number of coolant tubes
vehicleThermal.radiator_tube_H = 0.0015; % [m] Height of each coolant tube
vehicleThermal.radiator_fin_spacing = 0.002; % Fin spacing
vehicleThermal.radiator_wall_thickness = 1e-4; % [m] Material thickness
vehicleThermal.radiator_wall_conductivity = 240; % [W/m/K] Material thermal conductivity

vehicleThermal.radiator_gap_H = (vehicleThermal.radiator_H - vehicleThermal.radiator_N_tubes*vehicleThermal.radiator_tube_H) / (vehicleThermal.radiator_N_tubes - 1); % [m] Height between coolant tubes
vehicleThermal.radiator_air_area_flow = (vehicleThermal.radiator_N_tubes - 1) * vehicleThermal.radiator_L * vehicleThermal.radiator_gap_H; % [m^2] Air flow cross-sectional area
vehicleThermal.radiator_air_area_primary = 2 * (vehicleThermal.radiator_N_tubes - 1) * vehicleThermal.radiator_W * (vehicleThermal.radiator_L + vehicleThermal.radiator_gap_H); % [m^2] Primary air heat transfer surface area
vehicleThermal.radiator_N_fins = (vehicleThermal.radiator_N_tubes - 1) * vehicleThermal.radiator_L / vehicleThermal.radiator_fin_spacing; % Total number of fins
vehicleThermal.radiator_air_area_fins = 2 * vehicleThermal.radiator_N_fins * vehicleThermal.radiator_W * vehicleThermal.radiator_gap_H; % [m^2] Total fin surface area
vehicleThermal.radiator_tube_Leq = 2*(vehicleThermal.radiator_H + 20*vehicleThermal.radiator_tube_H*vehicleThermal.radiator_N_tubes); % [m] Additional equivalent tube length for losses due to manifold and splits

vehicleThermal.fan_area = 0.25 * 2; % [m^2] Fan flow area (2 fans)


vehicleThermal.cabin_duct_area = 0.04; % [m^2] Air duct cross-sectional area
vehicleThermal.cabin_p_init   = 0.101325;
vehicleThermal.cabin_RH_init  = 0.4;
vehicleThermal.cabin_CO2_init = 4e-4;
vehicleThermal.coolant_p_init = 0.101325;
vehicleThermal.ambient=25+273.15;          %[K] Ambient temperature in K

vehicleThermal.coolant_T_init=25+273.155;  % [K] Coolant initial temperature
vehicleThermal.coolant_pipe_D = 0.019; % [m] Coolant pipe diameter