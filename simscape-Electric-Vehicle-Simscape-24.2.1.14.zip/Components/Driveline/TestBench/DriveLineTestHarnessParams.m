% Copyright 2025 The MathWorks, Inc.

%Driveline parameters
DrivelineWithBrakingParams;