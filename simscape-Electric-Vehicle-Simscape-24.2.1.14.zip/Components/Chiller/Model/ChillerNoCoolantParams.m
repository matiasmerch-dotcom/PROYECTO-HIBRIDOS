% Copyright 2025 The MathWorks, Inc.

%
chiller.chillerMaxPower = 6000;
