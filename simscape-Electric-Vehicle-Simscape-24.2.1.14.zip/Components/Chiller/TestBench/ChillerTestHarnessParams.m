% Copyright 2025 The MathWorks, Inc.

%Chiller parameters
ChillerParams;

%Vehicle Parameters
vehicleThermal.coolant_channel_D = 0.0092; % [m] Coolant jacket channels diameter