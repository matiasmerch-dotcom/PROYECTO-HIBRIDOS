% Copyright 2025 The MathWorks, Inc.

%
%% Battery CC-CV batteryCharger and Thermal parameters
ChargerThermalParams;