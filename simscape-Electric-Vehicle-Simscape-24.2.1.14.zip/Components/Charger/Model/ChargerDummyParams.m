% Copyright 2025 The MathWorks, Inc.

%
%% Dummy charger - no parameter
