% Copyright 2022 - 2025 The MathWorks, Inc.


BMSParams;
load('TestSeqBusObject.mat')%#ok<*LOAD>

