% Copyright 2025 The MathWorks, Inc.

%Battery Heater Vriables
HeaterParams;

%Harness Variables
vehicleThermal.coolant_channel_D = 0.0092; % [m] Coolant jacket channels diameter